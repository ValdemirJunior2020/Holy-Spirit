export const API_BASE = (import.meta.env.VITE_API_BASE || "").replace(/\/$/, "");

function joinUrl(base, path) {
  if (!base) return path; // lets Netlify redirects handle /api/*
  if (!path) return base;
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  if (path.startsWith("/")) return `${base}${path}`;
  return `${base}/${path}`;
}

async function safeReadText(res) {
  try {
    return await res.text();
  } catch (err) {
    void err; // satisfy eslint no-unused-vars
    return "";
  }
}

export async function postJSON(path, payload) {
  const url = joinUrl(API_BASE, path);

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload ?? {}),
  });

  const raw = await safeReadText(res);
  let data = null;

  if (raw) {
    try {
      data = JSON.parse(raw);
    } catch (err) {
      void err; // satisfy eslint no-unused-vars
      data = null;
    }
  }

  if (!res.ok) {
    const msg = data?.error || raw || res.statusText || `HTTP ${res.status}`;
    throw new Error(msg);
  }

  return data ?? {};
}
